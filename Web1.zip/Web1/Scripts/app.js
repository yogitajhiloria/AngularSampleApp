﻿(function () {
    var app = angular.module('myApp', ['ngRoute', 'ngAnimate']);
    app.config(function ($routeProvider, $httpProvider) {
        $routeProvider
            .when("/", {
                templateUrl: "UserView.html",
                controller: "UserController"
            })
            .when("/Post/:userid", {
                templateUrl: "PostView.html",
                controller: "PostController"
            })
            .when("/List", {
                templateUrl: "UserGridView.html",
                controller: "UserController"
            })
            .when("/Animation", {
                templateUrl: "TestAnimation.html",
                controller: "UserController"
            })
            .otherwise({ redirectTo: "/" });
        //$httpProvider.defaults.headers.common['Access-Control-Allow-Origin'] = "*";
        //$httpProvider.defaults.headers.common['Access-Control-Max-Age'] = '1728000';
    });
}());