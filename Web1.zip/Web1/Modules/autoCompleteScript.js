﻿$(document).ready(function () {
    $('input.typeahead').typeahead({

    });
});