﻿(function () {
    var app = angular.module('myApp');
    app.directive('starformator', function () {
        return {
            restrict: 'AEC',
            scope: {
                selectedstar: '=', // update object expecting object both ways
                prompt: '@',  //@ expecting string
                title: '@',
                itemid: '@',
                subtitle: '@',
                model: '=',   // Scope
                AvgStar : '=',
                onselected: '&' //& function
            },
            link: function (scope, elem, attrs) {
                scope.RatingClick = function (rating) {
                    scope.selectedstar = rating;
                    if (scope.onselected != undefined) {
                        scope.onselected(rating);
                    }
                    
                };
            },
            templateUrl: '../Templates/StarTemplate.html'

        };
    });
}());