﻿(function () {
    var app = angular.module('myApp');
    var MainController = function ($scope, ApiService) {
        //$scope.hideProgressBar = false;
        //$scope.HideProgressBarFun = function () {
        //    $scope.hideProgressBar = true;
        //}
        //console.log("surveyid ");
        ApiService.GetUserArray().then(function (data) {
           // console.log("getting data ");
            $scope.searchData = data;
        });
        $scope.onItemSelected = function () { // this gets executed when an item is selected
            $scope.$root.$broadcast("myEventForPost", {
                value: $scope.SelectedName
            });
            console.log('selected=' + $scope.SelectedName);
        };
    };

    app.controller('MainController', ['$scope', 'ApiService', MainController]);
}());