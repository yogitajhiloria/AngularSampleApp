﻿(function () {
    var app = angular.module('myApp');
    var AddPostController = function ($scope, ApiService, $routeParams, LocalDataService) {
        var useriD = $routeParams.userid;
        var getUserDetails = function () {
            var user = LocalDataService.GetUser();
            if (user == null || user.id != useriD) {
                ApiService.GetSpecificUser(useriD).then(function (response) {
                    $scope.userName = response.username;
                });

            } else {
                $scope.userName = user.username;
            }
        };
        getUserDetails();
        $scope.AddPost = function () {
            console.log("called Add post");
            if (!$scope.texttitle || !$scope.textbody || !useriD) {
                return;
            }
            var data = {
                "userId": parseInt(useriD),
                "title": $scope.texttitle,
                "body": $scope.textbody
            }
            ApiService.AddNewPost(data).then(function (response) {
                $scope.postResult = "Post Added";
                // instead of clearing that call reset functionality and change form state
                $scope.texttitle = "";
                $scope.textbody = "";
                $scope.$parent.getUserDetails();
                $scope.postForm.$setPristine();
            }, function (error) {
                $scope.postResult = "Error Occured";
                console.log(error);
            });
        };
        $scope.clear = function () {
            $scope.postResult = "";
            $scope.postForm.$setPristine();
           
        };
    };
    app.controller('AddPostController', ['$scope', 'ApiService', '$routeParams', 'LocalDataService', AddPostController]);
}());