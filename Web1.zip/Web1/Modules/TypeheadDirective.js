﻿(function () {
    var app = angular.module('myApp');
    // Directive name should be lowercase otherwise it will giver error
    app.directive('typeahead', function ($timeout) {
        return {
            restrict: 'AEC',
            scope: {
                items: '=', // update object expecting object both ways
                prompt: '@',  //@ expecting string
                title: '@',
                itemid: '@',
                subtitle: '@',
                model: '=?',   // Scope
                selecteditem: '=',
                onselect: '&' //& function
            },
            link: function (scope, elem, attrs) {
                scope.handleSelection = function (selItem,text) {
                    scope.model = text;
                    scope.selecteditem = selItem;
                    scope.current = 0;
                    scope.selected = true;
                    $timeout(function () {
                        scope.onselect();
                    }, 200);
                };
                scope.textChange = function () {
                    if (scope.model == '') {
                        console.log("Got into text cghange");
                        scope.selecteditem = 0;
                        $timeout(function () {
                            scope.onselect();
                        }, 200);
                    }
                };
                scope.current = 0;
                scope.selected = true; // hides the list initially
                scope.isCurrent = function (index) {
                    return scope.current == index;
                };
                scope.setCurrent = function (index) {
                    scope.current = index;
                };
            },
            templateUrl: '../Templates/typeHeadTemplate.html'

        };
    });
}());