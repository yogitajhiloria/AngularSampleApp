﻿(function () {
    var app = angular.module('myApp');

   
    var UserController = function ($scope, ApiService, $location, LocalDataService) {
        //var GetOfflineUser = function () {
        //    console.log("Unable to connect to API");
            
        //    $http.get("../Data/OfflineUsers.json").success(function (data) {
        //        $scope.UsersDetails = data;
        //        $scope.counter = 10;
        //        $scope.hideProgressBar = true;
        //    }
        //    );
        //};
        //$injector.invoke(MainController, this, {
        //    $scope: $scope
        //});
        if (null == '') {
            console.log('nuull==empty');
        } else {
            console.log('nuull!=empty');
        }
        if (null === '') {
            console.log('nuull===empty');
        } else {
            console.log('nuull!==empty');
        }
        $scope.pageclass = "page-user";
        $scope.Nodatafound = true;
        var onError = function (reason) {
            console.log("Could not fetch the data. " + reason);
           // $scope.UsersDetails = null;
            $scope.Nodatafound = false;
            $scope.hideProgressBar = true;
        };
        var Users = function(data) {
            console.log("Got API");
            $scope.hideProgressBar = true;
            $scope.UsersDetails = data;
            //$scope.HideProgressBarFun();
           
        };
        var CallUsers = function () {
            ApiService.getUser().then(Users, onError);//, GetOfflineUser());
        };
        var GetUserImage = function GetUserImage(user) {
            if (user.avatar == undefined) {
                ApiService.getPhoto(user.id).then(function (response) {
                    user.avatar = response.thumbnailUrl;
                });
                //$http.get("http://jsonplaceholder.typicode.com/photos/" + user.id).success(function (response) {
                //    user.avatar = response.thumbnailUrl;
                //});
            }
        };
        $scope.RedirectToPost = function (user) {
            LocalDataService.SetSelectedUser(user);
            $location.path('/Post/' + user.id);
        };
        $scope.ShowUserData = function (user) {
            $scope.PopupUser = user;
        };
        $scope.firstName = "John";
        $scope.lastName = "Doe";
        CallUsers();
        $scope.ShowDetails = false;
        $scope.btnDetails = "More";
        $scope.hoverIn = function (user) {
            GetUserImage(user);
        };
        $scope.SetSelectedUser = 0;
        // got event from seach button
        $scope.$on("myEventForPost", function (event, args) {
            console.log('Event fired at TestController ' + args.value);
            $scope.SetSelectedUser = args.value.id;
        });
        $scope.incrementer = 0;
        $scope.filterUser = function (user) {
            if ($scope.SetSelectedUser > 0) {
                if (user.id == $scope.SetSelectedUser) {
                    return true;
                }
            } else {
                return true;
            }
            return false;
        };
    };

   
    app.controller('UserController', ['$scope', 'ApiService', '$location', 'LocalDataService', UserController]);
}());

