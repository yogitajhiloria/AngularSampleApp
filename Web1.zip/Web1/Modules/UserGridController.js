﻿(function () {
    var app = angular.module('myApp');
    var UserGridController = function ($scope, ApiService, LocalDataService, $filter) {
        $scope.pageclass = "page-list";
        var getUserImage = function () {
            ApiService.GetTotalPostCount().then(onsuccess, onerror);
        };
        var onsuccess = function (data) {
            $scope.$parent.UsersDetails.forEach(function (item, index) {
                var obj = $filter('filter')(data, function(d) { return d._id == item.id })[0];
                item.TotalPostCount = obj.count;
            });
        };
        var onerror = function (error) {
            console.log("error while calling total post couutn "+error);
        };
        $scope.loadTotalPost = getUserImage;
    };
    app.controller('UserGridController', ['$scope', 'ApiService', 'LocalDataService', '$filter', UserGridController]);
}());