﻿(function () {
    var app = angular.module('myApp');

    var PostControllers = function ($scope, ApiService, $routeParams, LocalDataService) {

        //$injector.invoke(MainController, this, {
        //    $scope: $scope
        //});
        var useriD = $routeParams.userid;
        $scope.pageclass = "page-post";
        $scope.getUserDetails = function() {
            ApiService.getPost(useriD).then(function(response) {
                $scope.UsersPosts = response;
                $scope.hideProgressBar = true;
            });
            var user = LocalDataService.GetUser();
            if (user == null || user.id != useriD) {
                ApiService.GetSpecificUser(useriD).then(function(response) {
                    $scope.userName = response.username;
                    $scope.name = response.name;
                });

            } else {
                $scope.userName = user.username;
                $scope.name = user.name;
            }
        };
        var GetUserPhoto = function () {
            ApiService.getPhoto(useriD).then(function (response) {
                $scope.userAvatar = response.thumbnailUrl;
            });
        };
        $scope.SetSelectedUser = 0;
        $scope.$on("myEventForPost", function (event, args) {
            console.log('Event fired at PostControllers ' + args.value);
            $scope.SetSelectedUser = args.value.id;
            if ($scope.SetSelectedUser > 0) {
                useriD = $scope.SetSelectedUser;
            } else {
                useriD = $routeParams.userid;
            }
            $scope.hideProgressBar = false;
            $scope.getUserDetails();
            GetUserPhoto();
        });
        $scope.showAppPost = false;
        $scope.btnDetails = "Add New Post";
        $scope.getUserDetails();
        GetUserPhoto();
    };

    app.controller('PostController', ['$scope', 'ApiService', '$routeParams', 'LocalDataService', PostControllers]);
}());