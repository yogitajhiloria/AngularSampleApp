﻿var mongo = require('mongodb');
var MongoClient = mongo.MongoClient;
var url = 'mongodb://localhost:27017/TestHtmlDb';
var ObjectId = require('mongodb').ObjectID;

var handlerConnectionError = function (err, callback) {
    if (err) {
        console.log(JSON.stringify(err));
        callback(err, null);
        return;
    }
};

var GetAllUsers = function(db, searchcondition, callback) {
    var cursor;
    //'Mycollection'
    cursor = db.collection(searchcondition.collectionName).find(searchcondition.findCondition);    
    var userarray = [];
    cursor.each(function(err, doc) {
        handlerConnectionError(err, callback);
        if (doc != null) {
            userarray.push(doc);
        } else {
            callback(null,userarray);
        }
    });
};

var updateDB = function (db, searchcondition, callback) {
    //'Mycollection' insertedCount
    //var maxid = db.collection(searchcondition.collectionName).find().sort({ id: -1 }).limit(1);
    //var userarray = [];
    //var next = function (id) {
        //searchcondition.data.id = id + 1;
       // searchcondition.data.userId = searchcondition.findCondition.id;
        db.collection(searchcondition.collectionName).insert(searchcondition.data, function (error, result) {
            if (error) {
                handlerConnectionError(error, callback);
            } else {
                var successResult = { result: 'success' };
                callback(null, successResult);
            }
        });  
    //};

    //maxid.each(function (err, doc) {
    //    handlerConnectionError(err, callback);
    //    if (doc != null) {
    //        userarray.push(doc);
    //        next(userarray[0].id);
    //    }
    //});

     
};
var getMaxId = function (db, searchcondition, callback) {
    var cursor = db.collection(searchcondition.collectionName).find().sort({ id: -1 }).limit(1);
    cursor.each(function (err, doc) {
        handlerConnectionError(err, callback);
        if (doc != null) {
            //doc
            callback(null, doc.id);
        } 
    });
};

var getGroupData = function (db, searchcondition, callback) {
    var cursor = db.collection(searchcondition.collectionName).aggregate([
        { $group: { "_id": "$userId", "count": { $sum: 1 } } }
    ]);
    var userarray = [];
    cursor.each(function (err, doc) {
        handlerConnectionError(err, callback);
        if (doc != null) {
           // console.log(doc);
            userarray.push(doc);
        } else {
            callback(null, userarray);
        }
    });
};

exports.connectToDB = function(searchcondition, onEndCallback) {
    MongoClient.connect(url, function(err, db) {
        handlerConnectionError(err, onEndCallback);
        var callDBProcessor;
        if (searchcondition.isUpdate) {
            callDBProcessor = updateDB;
        } else if (searchcondition.isGetMaxid) {
            callDBProcessor = getMaxId;
        } else if (searchcondition.isUserGroup) {
            callDBProcessor = getGroupData;
        }
        else {
            callDBProcessor = GetAllUsers;
        }
        //assert.equal(null, err);
        callDBProcessor(db, searchcondition, function (errs, userarray) {
            db.close();
            if (errs) {
                handlerConnectionError(err, onEndCallback);
            } else {
                onEndCallback(null, userarray);
            }
        });
        console.log("Connected correctly to server.");

    });
};
