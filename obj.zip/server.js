﻿//var http = require('http');
var express = require('express');
var app = express();
var mongo = require('mongodb');
var MongoClient = mongo.MongoClient;
var url = 'mongodb://localhost:27017/TestHtmlDb';
var ObjectId = require('mongodb').ObjectID;
var port = process.env.PORT || 8080;
var iConnect = require('./DBConnect.js');
var bodyParser = require("body-parser");
var extraurlPath = process.env["HandlerURL"] || "";
var multer = require('multer');
var uploadpath= process.env["UploadPath"] || "";
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
/*
var port = process.env.port || 1337;
http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Hello World\n');
}).listen(port);
 */

//app.use(require('express-promise')());

//MongoClient.addListener('error', function (e) {
//    console.log(e);
//});
var mainrouter = express.Router();
var updaterouter = express.Router();
var selectouter = express.Router();
var uploaddatarouter = express.Router();
var headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'content-type');
    
    console.log(req.originalUrl); // '/admin/new'
    //console.log(req.baseUrl); // '/admin'
    //console.log(req.path); // '/new'
    next();
});
var sendDatatoClient = function (res, error, data) {
    if (error && error !== "0") {
        res.writeHead(500, "Internal Server Error", headers);
        var errorMessage = { Error: error };
        //res.end(JSON.stringify(errorMessage));
        res.end(errorMessage);
    } else {
        res.writeHead(200, "OK", headers);
        //res.end(JSON.stringify(data));
        res.end(data);
    }
   
};

mainrouter.get('/', function (req, res) {
   
    var condition = { collectionName: 'Mycollection', findCondition: null };
    iConnect.connectToDB(condition, function (err,data) {
        sendDatatoClient(res, err, data);
        });
    //res.send(result);
});


mainrouter.get('/posts/:id', function (req, res) {
    
    var useridSearch = { "id": parseInt(req.params.id) };
    var condition = { collectionName: 'postcollection', findCondition: useridSearch };
    iConnect.connectToDB(condition, function (error,data) {
        sendDatatoClient(res,error,data);
    });
    //res.send(result); req.query
});
mainrouter.get('/posts', function (req, res) {
    var useridSearch = null;
    if (req.query.userid) {
        useridSearch = { "userId": parseInt(req.query.userid) };    
    } 
    
    var condition = { collectionName: 'postcollection', findCondition: useridSearch };
    iConnect.connectToDB(condition, function (error, data) {
        
        sendDatatoClient(res, error, data);
        //res.end(data);
    });
    //res.send(result); req.query
});
mainrouter.get('/:userid', function (req, res) {
    
    var useridSearch = { "id": parseInt(req.params.userid) };
    var condition = { collectionName: 'Mycollection', findCondition: useridSearch };
    iConnect.connectToDB(condition, function (error, data) {
        sendDatatoClient(res, error, data[0]);
    });
    //res.send(result);
});

//updaterouter.post('/:userid', function (req, res) {
    
//    var useridSearch = { "id": parseInt(req.params.userid) };
//    var condition = { collectionName: 'postcollection', findCondition: useridSearch, isUpdate: true ,data : req.body};
//    iConnect.connectToDB(condition, function (err, data) {
//        sendDatatoClient(res, err, data);
//    });
//    //////res.send(result);
//});

updaterouter.post('/', function (req, res) {
    
   // var useridSearch = { "id": parseInt(req.params.userid) };
    var condition = { collectionName: 'postcollection', findCondition: null,isGetMaxid:true, isUpdate: false , data : req.body };
    iConnect.connectToDB(condition, function (err, data) {
        if (err) {
            sendDatatoClient(res, err, data);
            return;
        }
        condition.isUpdate = true;
        condition.isGetMaxid = false;
        condition.data.id = data+1;
        iConnect.connectToDB(condition, function (err, data) {
            sendDatatoClient(res, err, data);
        });
    });
   
    //res.send(result);
});
//http://jsonplaceholder.typicode.com/posts

selectouter.get('/User', function (req, res) {

    var condition = { collectionName: 'postcollection', isUserGroup: true };

    iConnect.connectToDB(condition, function(error, data) {
        sendDatatoClient(res, error, data);
    });
});
var storage = multer.diskStorage({
 //multers disk storage settings
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        var datetimestamp = Date.now();
        cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1]);
    }
});
var upload = multer({
 //multer settings
    storage: storage
}).single('file');
uploaddatarouter.post('/profilepic', function(req, res) {
    // for upload use Mycollection
    // pass userid to update collection with url path while uploading
    // need to change body
    var condition = { collectionName: 'Mycollection', findCondition: null, isGetMaxid: true, isUpdate: true , data : req.body };
    upload(req, res, function(err) {
        if (err) {
            res.json({ error_code: 1, err_desc: err });
            return;
        }
        // Sucess Call
        res.end("{'sucess':'true'}");
        //iConnect.connectToDB(condition, function (err, data) {
        //    if (err) {
        //        sendDatatoClient(res, err, data);
        //        return;
        //    }
        //    condition.isUpdate = true;
        //    condition.isGetMaxid = false;
        //    condition.data.id = data + 1;
        //    iConnect.connectToDB(condition, function (err, data) {
        //        sendDatatoClient(res, err, data);
        //    });
        //});
    });
   

});

app.use(extraurlPath + '/upload', uploaddatarouter);
app.use(extraurlPath + '/listUsers', mainrouter);
app.use(extraurlPath + '/UpdateUsers', updaterouter);
app.use(extraurlPath + '/Select', selectouter);
var server = app.listen(port, function() {

    var host = server.address().address;
    var port = server.address().port;

    console.log("MongodDB Exp server app listening at http://%s:%s", host, port);

});